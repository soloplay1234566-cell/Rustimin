@echo off
setlocal
cd /d "%~dp0"
if not exist "app\.ready" (
  echo Extracting Rustimin. Please wait...
  "7za.exe" x "application.7z" -o"app" -y
  if errorlevel 1 (
    echo Extraction failed. Extract the entire ZIP into a writable folder and try again.
    pause
    exit /b 1
  )
  if not exist "app\Rustimin.exe" (
    echo Rustimin.exe was not extracted.
    pause
    exit /b 1
  )
  type nul > "app\.ready"
)
start "" "%~dp0app\Rustimin.exe"
